# LangChain Tutorials

Overview and tutorial of the [LangChain library](https://langchain.readthedocs.io/en/latest/)

See the accompanying YouTube tutorials @ https://www.youtube.com/channel/UCyR2Ct3pDOeZSRyZH5hPO-Q

If you want to get updated when new tutorials are out, sign up at [DataIndependent](https://dataindependent.com/)

This series is provided by and associated with [DataIndependent](https://dataindependent.com/)
