# podcast2chat
Incorporating Youtube Podcaster into an AI-Powered Chatbot Interface using Gradio, LangChain, GPTIndex and GPT-3
