# General & practical

# **Address, route, directions and basic information**

[https://goo.gl/maps/q5tMWGjwBLv](https://goo.gl/maps/q5tMWGjwBLv)

**Address:**

Blendle HQ

Catharijnesingel 52

3511 GC Utrecht, NL

4th floor

---

**Route:**

By public transportation, from Utrecht CS trains: [https://www.youtube.com/watch?v=aWMWofU5-FA](https://www.youtube.com/watch?v=aWMWofU5-FA)

By car: park here: [http://www.interparking.nl/nl-NL/find-parking/P1 Moreelsepark/](http://www.interparking.nl/nl-NL/find-parking/P1%20Moreelsepark/) Blendle can reimburse parkings tickets for guests. 

---

**KVK (Chamber of commerce) number:**

58724109

---

**BTW (VAT) number:**

[Here](https://www.notion.so/1fbb88c6735343c8a3ba8b409ed124d4) (non public)

---

# **Security and access to the office**

---

[More about entry to the office](https://www.notion.so/8354943cbce846e086ad48e67dc153bc) (non public)

---

# Work at Blendle

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). 

[Tools and tips](General%20&%20practical%20b2682126db8e47bf8e5fabb8b5b4c1ce/Tools%20and%20tips%20b5db3475cf1543e28b7f7dc9c4935e6d.md)

[History](General%20&%20practical%20b2682126db8e47bf8e5fabb8b5b4c1ce/History%20a51acfa8132146a69ffa5d6718fdb33a.md)